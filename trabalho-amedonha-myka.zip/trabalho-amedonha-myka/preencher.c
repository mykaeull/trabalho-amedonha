// Bruna Raynara Maia Batista - 499257
// Carlos Alberto Sampaio Sales Junior - 485181
// Domingos Mykaeull Gomes Peres - 500594

#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

void preencher_alfabeto(char *alfabeto) { // Carlos
  alfabeto[0] = 'a';
  alfabeto[1] = 'b';
  alfabeto[2] = 'c';
  alfabeto[3] = 'd';
  alfabeto[4] = 'e';
  alfabeto[5] = 'f';
  alfabeto[6] = 'g';
  alfabeto[7] = 'h';
  alfabeto[8] = 'i';
  alfabeto[9] = 'j';
  alfabeto[10] = 'l';
  alfabeto[11] = 'm';
  alfabeto[12] = 'n';
  alfabeto[13] = 'o';
  alfabeto[14] = 'p';
  alfabeto[15] = 'q';
  alfabeto[16] = 'r';
  alfabeto[17] = 's';
  alfabeto[18] = 't';
  alfabeto[19] = 'u';
  alfabeto[20] = 'v';
  alfabeto[21] = 'x';
  alfabeto[22] = 'z';
}

void preencher_categoria(char **categoria) { // Carlos
    categoria[0] = "profissoes";
    categoria[1] = "nomes de pessoas";
    categoria[2] = "nomes de cidade";
    categoria[3] = "nomes de animais";
    categoria[4] = "nomes de comida";
}